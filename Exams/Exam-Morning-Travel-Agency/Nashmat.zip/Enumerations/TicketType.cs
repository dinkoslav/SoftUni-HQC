﻿namespace TravelAgency.Enumerations
{
    public enum TicketType
    {
        Air,
        Bus,
        Boat,
        Train
    }
}
