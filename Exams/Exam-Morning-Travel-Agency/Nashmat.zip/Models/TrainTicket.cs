﻿namespace TravelAgency.Models
{
    internal class TrainTicket : Ticket
    {
        private const string TicketType = "train";

        public TrainTicket(string from, string to, string dateAndTime)
        {
            this.From = from;
            this.To = to;
            this.DateAndTime = Ticket.ParseDateTime(dateAndTime);
        }

        public TrainTicket(string from, string to, string dateAndTime, string price, string specialPrice)
            : this(from, to, dateAndTime)
        {
            this.Price = decimal.Parse(price);
            this.SpecialPrice = decimal.Parse(specialPrice);
        }

        public override string Type
        {
            get
            {
                return TicketType;
            }
        }

        public override string Description
        {
            get
            {
                return this.Type + ";;" + this.From + ";" + this.To + ";" + this.DateAndTime + ";";
            }
        }
    }
}
