﻿namespace VehicleParkSystem.Interfaces
{
    public interface IEngine
    {
        void ProcessCommand();
    }
}
